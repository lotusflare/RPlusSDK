#import <React/RCTBridgeModule.h>

@interface RCT_EXTERN_MODULE(RPlus, NSObject)

RCT_EXTERN_METHOD(start:(NSString *)clientId withClentKey:(NSString *)clientKey withUserAuth:(NSString *)userAuth)

RCT_EXTERN_METHOD(startRPlus:(NSString *)clientId 
                withClentKey:(NSString *)clientKey 
                withUserAuth:(NSString *)userAuth 
                 withResolve:(RCTPromiseResolveBlock)resolve 
                  withReject:(RCTPromiseRejectBlock)reject)

+ (BOOL)requiresMainQueueSetup
{
  return NO;
}

@end
