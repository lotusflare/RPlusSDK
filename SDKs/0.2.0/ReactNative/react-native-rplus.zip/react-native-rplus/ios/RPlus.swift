import RPlusIOSLibrary

@objc(RPlus)
class RPlus: NSObject {
  
  @objc(start:withClentKey:withUserAuth:)
  func start(clientId: String, clientKey: String, userAuth: String) -> Void {
    guard !clientId.isEmpty, !clientKey.isEmpty, !userAuth.isEmpty else { return }
    let config = RPlusConfiguration.configuration
    config.clientId = clientId
    config.clientKey = clientKey
    config.userAuth = userAuth
    RPlusManager.shared.startRPlus(withConfig: config) { _, error in
      if let error { print("Error: \(error.description)") }
    }
  }

  @objc(startRPlus:withClentKey:withUserAuth:withResolve:withReject:)
  func startRPlus(clientId: String, clientKey: String, userAuth: String, resolve: @escaping RCTPromiseResolveBlock, reject: @escaping RCTPromiseRejectBlock) -> Void {
    guard !clientId.isEmpty, !clientKey.isEmpty, !userAuth.isEmpty else { 
      return reject("1001", "config error", nil) 
    }
    let config = RPlusConfiguration.configuration
    config.clientId = clientId
    config.clientKey = clientKey
    config.userAuth = userAuth
    RPlusManager.shared.startRPlus { result, error in
      if let error { 
        reject("\(error.code)", error.localizedDescription, nil) 
      } else { 
        resolve(result) 
      }
    }
  }
}