import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'dart:async' show Future;

class RPlus {
  static const MethodChannel _channel = MethodChannel('com.lotusflare.rplus');

  static Future<bool?> startRPlus(String clientId, String clientKey, String userAuth) async {
    final result = await _channel.invokeMethod<bool>('startRPlus', { 'clientId': clientId, 'clientKey': clientKey, 'userAuth': userAuth });
    if (kDebugMode) {
      print(result);
    }
    return result;
  }
}