import Flutter
import UIKit
import RPlusIOSLibrary

public class RPlusFlutterPlugin: NSObject, FlutterPlugin {
  public static func register(with registrar: FlutterPluginRegistrar) {
    let channel = FlutterMethodChannel(name: "com.lotusflare.rplus", binaryMessenger: registrar.messenger())
    let instance = RPlusFlutterPlugin()
    registrar.addMethodCallDelegate(instance, channel: channel)
  }

  public func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
    switch call.method {
    case "startRPlus":
      let args: [String: String]? = call.arguments as? [String : String]
      let config = RPlusConfiguration.configuration
      config.clientId = args?["clientId"] ?? ""
      config.clientKey = args?["clientKey"] ?? ""
      config.userAuth = args?["userAuth"] ?? ""
      RPlusManager.shared.startRPlus { res, error in
        if let error {
            result(FlutterError(code: "\(error.code)", message: error.localizedDescription, details: nil))
        } else {
            result(res)
        }
      }
    default:
      result(FlutterMethodNotImplemented)
    }
  }
}
