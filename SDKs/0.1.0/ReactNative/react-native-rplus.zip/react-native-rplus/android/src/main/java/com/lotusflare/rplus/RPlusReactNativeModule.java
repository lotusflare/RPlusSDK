package com.lotusflare.rplus;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.lotusflare.rplus.RPlusSDK;

public class RPlusReactNativeModule extends ReactContextBaseJavaModule {

    private static final String NAME = "RPlus";
    private ReactApplicationContext reactContext;

    public RPlusReactNativeModule(ReactApplicationContext reactContext) {
        super(reactContext);
        this.reactContext = reactContext;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @ReactMethod
    public void start(String clientId, String clientKey, String userAuth) {
        RPlusSDK.INSTANCE.startRPlus(reactContext, clientId, clientKey, userAuth);
    }
}

