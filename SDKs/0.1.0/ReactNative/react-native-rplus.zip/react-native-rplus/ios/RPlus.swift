import RPlusIOSLibrary

@objc(RPlus)
class RPlus: NSObject {
  
  @objc(start:withClentKey:withUserAuth:)
  func start(clientId: String, clientKey: String, userAuth: String) -> Void {
    guard !clientId.isEmpty, !clientKey.isEmpty, !userAuth.isEmpty else { return }
    let config = RPlusConfiguration.configuration
    config.clientId = clientId
    config.clientKey = clientKey
    config.userAuth = userAuth
    RPlusManager.shared.startRPlus(withConfig: config) { _, error in
      if let error { print("Error: \(error.description)") }
    }
  }
}
