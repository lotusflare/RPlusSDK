import { NativeModules, Platform } from "react-native";

const LINKING_ERROR =
  `The package 'react-native-rplus' doesn't seem to be linked. Make sure: \n\n` +
  Platform.select({ ios: "- You have run 'pod install'\n", default: "" }) +
  "- You rebuilt the app after installing the package\n" +
  "- You are not using Expo Go\n";

const RPlus = NativeModules.RPlus
  ? NativeModules.RPlus
  : new Proxy(
      {},
      {
        get() {
          throw new Error(LINKING_ERROR);
        },
      }
    );

/**
 * Start rplus
 * @param clientId rplus client id
 * @param clientKey rplus client key
 * @param userAuth rplus userAuth
 * @returns null
 */

export function startRPlus(
  clientId: string,
  clientKey: string,
  userAuth: string
) {
  return RPlus.start(clientId, clientKey, userAuth);
}
